package com.jwt.example.services;

import com.jwt.example.models.User;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class UserService {

    private List<User> store=new ArrayList<>();

    public UserService() {
        store.add(new User(UUID.randomUUID().toString(),"Amol More","amol@dev.in"));
        store.add(new User(UUID.randomUUID().toString(),"Anjal More","anjal@dev.in"));
        store.add(new User(UUID.randomUUID().toString(),"Raj More","raj@dev.in"));
        store.add(new User(UUID.randomUUID().toString(),"Yog More","yog@dev.in"));
    }

    public List<User> getUsers(){
        return this.store;
    }
}
